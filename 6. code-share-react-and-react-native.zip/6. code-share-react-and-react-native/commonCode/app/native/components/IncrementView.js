import React, { Component } from 'react';
import {
  View,
  Text,
} from 'react-native';

export default class IncrementView extends Component {
  render() {
    const { onPress, count } = this.props;
    return (
      <View>
        <Text onPress={onPress}>{'Increment Button'}</Text>
        <Text>{`${count}`}</Text>
      </View>
    );
  }
}
