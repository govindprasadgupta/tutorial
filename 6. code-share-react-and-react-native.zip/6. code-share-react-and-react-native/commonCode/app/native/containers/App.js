import React, { Component } from 'react';
import { View } from 'react-native';
import { connect }  from 'react-redux';
import { appStyle } from '../styles/styles';
import Header     from '../components/Header';
import IncrementView from '../components/IncrementView';
// actions
import {
  counterIncrement,
} from '../../actions/CounterAction';

/** The app entry point */
class App extends Component {
  render() {
    // injected by connect call
    const {increment, count } = this.props;

    return (
      <View style={appStyle.reactNativeWeb}>
        <Header />
        <IncrementView
          onPress={increment}
          count={count}
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  count: state.CounterReducer.count,
});

const mapDispatchToProps = (dispatch) => ({
  increment: () => dispatch(counterIncrement()),
});


export default connect(mapStateToProps, mapDispatchToProps)(App);

