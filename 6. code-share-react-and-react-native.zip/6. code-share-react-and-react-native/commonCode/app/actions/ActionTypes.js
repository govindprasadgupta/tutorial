
const Actions = {
  INCREMENT_COUNTER: 'INCREMENT_COUNTER',
};

export default Actions;