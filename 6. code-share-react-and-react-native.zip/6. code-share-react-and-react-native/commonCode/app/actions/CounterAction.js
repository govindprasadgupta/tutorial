import Actions from './ActionTypes';


export const counterIncrement = () => ({
  type: Actions.INCREMENT_COUNTER,
});



