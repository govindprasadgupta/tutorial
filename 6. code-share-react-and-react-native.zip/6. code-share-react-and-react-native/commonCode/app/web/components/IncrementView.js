import React, { Component } from 'react';

export default class IncrementView extends Component {

  render() {
    const { onPress, count } = this.props;
    return (
      <div onClick={onPress} >
      <div className="Increment" style={{color: 'red'}}>{'Increment Button'}</div>
      <div className="count">{`${count}`}</div>
      </div>
    );
  }
}