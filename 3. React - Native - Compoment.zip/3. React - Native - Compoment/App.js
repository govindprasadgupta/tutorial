/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  Modal,
  Keyboard,
  Alert
} from 'react-native';

export default class App extends Component {

  constructor(props) {
    super(props);
    this.state = {text: '', modalVisible: false};
  }

  render() {
    return (
      <View style={{flex: 1, paddingTop: 60, padding:20}}>
        <Text style={{fontWeight: 'bold', fontSize:30}}>
        {'I am bold'}
          <Text style={{color: 'red', fontSize:20}}  onPress={() =>{
            this.setState({modalVisible: true})
          } } >
          {' and red. \n Present modal'}
          </Text>
        </Text>
        <TextInput
         style={{height: 40, borderColor: 'gray', borderWidth: 1, marginTop: 40}}
         onChangeText={(text) => this.setState({text})}
         onEndEditing={() => Alert.alert('Text input editing end')}
        autoCorrect={false}
        maxLength={40}
        editable={true}
        underlineColorAndroid={'transparent'}
        value={this.state.text}
      />
        <TextInput
         style={{height: 40, borderColor: 'gray', borderWidth: 1, marginTop: 40}}
        onSubmitEditing={() => {
          Alert.alert('Input keyboard pressed');
          Keyboard.dismiss()
        }
        }
      />
      <Image source={{uri: 'https://facebook.github.io/react/logo-og.png'}} style={{flex: 1, marginTop: 20}} />
      <Image source={require('./src/filled_star.png')} />
      <Modal animationType="slide" 
          transparent={true} 
          visible={this.state.modalVisible}
          onRequestClose={() => { alert('Modal has been closed.'); }}>
        <View style={{height:300, width: 300, backgroundColor: 'red'}} />
        <Text style={{color: 'red', fontSize:20}}  onPress={() =>{
            this.setState({modalVisible: false})
          } } >
          {' Close modal'}
          </Text>
      </Modal>
      </View>
    );
  }
}

