import React, { Component } from 'react';
import {
  FlatList,
  SectionList,
  View,
  Text
} from 'react-native';

export default class Basic extends Component {


    render() {
       return (
         <View style={{flex: 1}}>
       <FlatList data={[{key: 'a'}, {key: 'b'}, {key: 'aa'}, {key: 'ba'}, {key: 'aaaa'}, {key: 'baaa'},{key: 'ab'}, {key: 'bbbb'}]} 
       renderItem={this.renderItem}
       keyExtractor={item => item.key}
       style={{margin: 60}}
       keyboardDismissMode={'on-drag'}
       keyboardShouldPersistTaps={'always'}
       bounces={true}
       extraData={null}
       ItemSeparatorComponent={() => <View style={{height: 1, backgroundColor: 'green'}} />}
       ListHeaderComponent={<Text>{'header'}</Text>}
      ListFooterComponent={<Text>{'footer'}</Text>}
       onScroll={(event) => {
          console.log('1')
      }}
      />
      <SectionList renderItem={this.renderItem}
       renderSectionHeader={({section: {title}}) => ( <Text style={{fontWeight: 'bold'}}>{title}</Text> )} 
       sections={[ {title: 'Title1', data: ['item1', 'item2']}, {title: 'Title2', data: ['item3', 'item4']}, {title: 'Title3', data: ['item5', 'item6']}, ]} 
       keyExtractor={(item, index) => item + index} />

      </View>);
    }

    renderItem ({item}){

      return (
        <Text style={{color: 'red', fontSize:20, height: 80,}}>{item.key}</Text>
      );
    } 
 }


  