/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  View
} from 'react-native';
import Basic from './src/basic';

export default class App extends Component {
  render() {
    return (
      <View style={{flex: 1, paddingTop: 60, padding:20}}>
        <Basic message={'Hello world'} pageTitle={'Basic'}/>
      </View>
    );
  }
}

