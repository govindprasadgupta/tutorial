import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Button,
  TouchableWithoutFeedback,
  TouchableHighlight,
  TouchableOpacity,
  Alert
} from 'react-native';
import { relativeTimeRounding } from 'moment';
export default class Basic extends Component {
  constructor(props) {
    super(props);
    this.state = {isShowingText: false};
  }

  renderFlex() {
    return (
      <View style={{flex: 1}}>
        <View style={{width: 100, height: 50, backgroundColor: 'powderblue'}} />
        <View style={{flex: 2, backgroundColor: 'skyblue'}} />
        <View style={{flex: 3, backgroundColor: 'steelblue'}} />
      </View>
    );
  }

  renderFlexBox() {
    return (
      <View style={{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <View style={{width: 100, height: 100, backgroundColor: 'powderblue'}} />
        <View style={{width: 100, height: 100, backgroundColor: 'skyblue'}} />
        <View style={{width: 100, height: 100, backgroundColor: 'steelblue'}} />
      </View>
    );
  }
  renderBasic(){
    const isShowingText = this.state.isShowingText;
    const { pageTitle, message } = this.props;
    const buttonText = isShowingText ? 'Hide' : 'Show';
    return (
      <View>
      <Text>
        {pageTitle}
      </Text>
      <Button 
         title={buttonText}
         color='blue'
         onPress={() => { 
            this.setState({isShowingText: !isShowingText});
         }}
      />
      {isShowingText && <Text style={styles.message}>
        {message}
      </Text> }
      </View>
    );
  }

  renderTouch() {
    return (
      < TouchableOpacity onPress={() => { Alert.alert('You tapped the button!'); }} > 
        <View style={{width: 100, height: 100, backgroundColor: 'powderblue'}} />
      </ TouchableOpacity >

    )
  }
    render() {
      // return this.renderBasic();
      // return this.renderFlex();
      // return this.renderFlexBox();
      return this.renderTouch();
    }
  }

  const styles = StyleSheet.create({
    message: {
      backgroundColor: 'red',
      width: 100,
      height: 60,
      textAlign: 'center',
    },
  });
  